const name = document.querySelector('#name')
const password = document.querySelector('#password')
const email = document.querySelector('#email')
const form = document.querySelector('#form')

function display(){
console.log('username');
console.log('password');
console.log('email');
}

form.addEventListener('submit',(e)=>{

let messages=[]
if(name.value =="" || name.value == null){
    messages.push('required name')
}

if(password.length)
if (password.length >=10){
    messages.push('password is long')
}


if(MessageChannel.length>0){
e.preventDefault()
errorelement.innerText =messages.join(',')
}
})